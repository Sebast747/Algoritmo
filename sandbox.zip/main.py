print("Hello CodeSandbox!")
print("sebas")
print("boxeo")
print("not time")
print("videojuegos")
print("soltero")
print("player")
print("valeria es mama")
print("naomi es infiel")
print("migue es esposo de nao")

""" vamos a concatenar """#alt+shift+a
nombre = "sebas"
apellido = "Osorio"
print("Hola mi nombre es:", nombre)
print("Hola mi nombre es:", nombre, apellido)
print("Hola mi nombre es:", nombre, "y mi apellido es:", apellido)

""" concatenación con diferentes tipos de datos  """
mi_edad=18
mi_nombre="sebas"
mi_apellido_paterno="Osorio"
mi_apellido_materno="Rendón"
soy_maestro= False
soy_estudiante= True

print("mi edad es:", mi_edad, ", mi nombre es:", mi_nombre, ", mi apellido paterno es:",mi_apellido_paterno,", mi apellido materno es", mi_apellido_materno,", ¿soy maestro?", soy_maestro,", ¿soy estudiante?",soy_estudiante )

""" uso de type - Averigua que tipo de dato recibes """
print(type(mi_edad))# <class 'int'>
print(type(mi_nombre))# <class 'str'>
print(type(soy_estudiante)) # <class 'bool'>

""" Operaciones matematicas """
numero_uno=15
numero_dos=10

print(numero_uno+numero_dos) #25
print(numero_uno-numero_dos) #5
print(numero_uno*numero_dos) #150
print(numero_uno/numero_dos) #1.0
print(numero_uno%numero_dos) #5

""" Mathematical operations """

#Ask the user to enter the numbers
number_one = int(input("Enter the first number: "))
number_two = int(input("Enter the second number: "))

#Perform the operation and show the result
print(number_one + number_two) 
print(number_one - number_two) 
print(number_one * number_two)
print(number_one / number_two)